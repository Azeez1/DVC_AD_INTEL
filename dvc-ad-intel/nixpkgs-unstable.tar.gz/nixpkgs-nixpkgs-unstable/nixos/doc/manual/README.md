[Moved to ./contributing-to-this-manual.chapter.md](./contributing-to-this-manual.chapter.md). Link:

https://nixos.org/manual/nixos/unstable/#chap-contributing
