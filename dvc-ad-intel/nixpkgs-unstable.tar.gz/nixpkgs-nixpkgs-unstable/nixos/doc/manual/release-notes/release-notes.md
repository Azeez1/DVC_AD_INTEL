# Release Notes {#ch-release-notes}

This section lists the release notes for each stable version of NixOS and current unstable revision.

```{=include=} sections
rl-2505.section.md
rl-2411.section.md
rl-2405.section.md
rl-2311.section.md
rl-2305.section.md
rl-2211.section.md
rl-2205.section.md
rl-2111.section.md
rl-2105.section.md
rl-2009.section.md
rl-2003.section.md
rl-1909.section.md
rl-1903.section.md
rl-1809.section.md
rl-1803.section.md
rl-1709.section.md
rl-1703.section.md
rl-1609.section.md
rl-1603.section.md
rl-1509.section.md
rl-1412.section.md
rl-1404.section.md
rl-1310.section.md
```
