# Automake {#setup-hook-automake}

Adds the `share/aclocal` subdirectory of each build input to the `ACLOCAL_PATH` environment variable.
