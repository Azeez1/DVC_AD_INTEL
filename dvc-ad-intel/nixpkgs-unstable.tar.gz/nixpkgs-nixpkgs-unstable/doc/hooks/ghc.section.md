# GHC {#ghc}

Creates a temporary package database and registers every Haskell build input in it (TODO: how?).
