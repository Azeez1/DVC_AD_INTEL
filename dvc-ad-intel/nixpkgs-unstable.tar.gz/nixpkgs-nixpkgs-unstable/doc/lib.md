# Nixpkgs `lib` {#id-1.4}

```{=include=} chapters
functions.md
module-system/module-system.chapter.md
```
