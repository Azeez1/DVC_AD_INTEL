# Development of Nixpkgs {#part-development}

This section shows you how Nixpkgs is being developed and how you can interact with the contributors and the latest updates.
If you are interested in contributing yourself, see [CONTRIBUTING.md](https://github.com/NixOS/nixpkgs/blob/master/CONTRIBUTING.md).

<!-- In the future this section should also include: How to test pull requests, how to know if pull requests are available in channels, etc. -->

```{=include=} chapters
development/opening-issues.chapter.md
```
