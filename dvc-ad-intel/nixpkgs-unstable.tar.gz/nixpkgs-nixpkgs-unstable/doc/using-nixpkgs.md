# Using Nixpkgs {#part-using}

```{=include=} chapters
using/platform-support.chapter.md
using/configuration.chapter.md
using/overlays.chapter.md
using/overrides.chapter.md
```
